#include "bsp_ps2.h"
#include "usbh_hid.h"

#include "FreeRTOS.h"

extern void PS2Control_Reset(void);
extern void PS2Control_Set(void);

//PS2�ֱ�����
static PS2_TYPE_t ps2_type = UnKnown_Dev;

//PS2 16��������ֵ��ȡ
static uint16_t ps2_KeyVal = 0;

extern PS2KEY_State_t ps2_checkkey(uint8_t bit);
extern uint8_t ps2_checkkeystate(uint8_t bit);

//usb�ֱ����ݽṹ��
PS2INFO_t ps2_info = { 
	.LX = 127,
	.LY = 127,
	.RX = 127,
	.RY = 127,
	.getKeyEvent = ps2_checkkey,
	.getKeyState = ps2_checkkeystate
};

//ps2�ֱ���Ĭ��ֵ,���ֱ����ֲ��ʱ�ָ�Ĭ��ֵ
PS2INFO_t ps2_defaultVal = {
	.LX = 127,
	.LY = 127,
	.RX = 127,
	.RY = 127,
	.getKeyEvent = ps2_checkkey,
	.getKeyState = ps2_checkkeystate
};

//PS2_HID����غ�������
static USBH_StatusTypeDef USBH_HID_InterfaceInit(USBH_HandleTypeDef *phost);
static USBH_StatusTypeDef USBH_HID_InterfaceDeInit(USBH_HandleTypeDef *phost);
static USBH_StatusTypeDef USBH_HID_ClassRequest(USBH_HandleTypeDef *phost);
static USBH_StatusTypeDef USBH_HID_Process(USBH_HandleTypeDef *phost);
static USBH_StatusTypeDef USBH_HID_SOFProcess(USBH_HandleTypeDef *phost);
static void USBH_HID_ParseHIDDesc(HID_DescTypeDef *desc, uint8_t *buf);

//usb�ֱ��ĳ�ʼ������
extern USBH_StatusTypeDef USBH_HID_PS2Init(USBH_HandleTypeDef *phost);

//����ps2��hid��
USBH_ClassTypeDef  PS2_HID_Class =
{
  .Name = "HID",
  .ClassCode = USB_HID_CLASS, //����ps2�ֱ�,Ĭ��ΪHID�豸
  .Init = USBH_HID_InterfaceInit,
  .DeInit = USBH_HID_InterfaceDeInit,
  .Requests = USBH_HID_ClassRequest,
  .BgndProcess = USBH_HID_Process,
  .SOFProcess = USBH_HID_SOFProcess,
  .pData = NULL,
};

USBH_ClassTypeDef  WiredlessPS2_HID_Class =
{
  .Name = "HID",
  .ClassCode = 0xff, //����ps2�ֱ�,��׿ģʽ��,ö��ʱ���෵�صĴ���Ϊ0xff
  .Init = USBH_HID_InterfaceInit,
  .DeInit = USBH_HID_InterfaceDeInit,
  .Requests = USBH_HID_ClassRequest,
  .BgndProcess = USBH_HID_Process,
  .SOFProcess = USBH_HID_SOFProcess,
  .pData = NULL,
};


/**
  * @brief  USBH_HID_InterfaceInit
  *         The function init the HID class.
  * @param  phost: Host handle
  * @retval USBH Status
  */
static USBH_StatusTypeDef USBH_HID_InterfaceInit(USBH_HandleTypeDef *phost)
{
  USBH_StatusTypeDef status;
  HID_HandleTypeDef *HID_Handle;
  uint16_t ep_mps;
  uint8_t max_ep;
  uint8_t num = 0U;
  uint8_t interface;

	USBH_UsrLog("start find interface now");
	
	//�ӿ�ƥ��,��Ҫ��������������ӿڽ���ƥ��
	//phost->device.CfgDesc.Itf_Desc[0,1,2,3...,n...].bInterfaceSubClass

	//0xff��ʾƥ����������
	interface = USBH_FindInterface(phost, 0xFFU, 0xFFU, 0xFFU);
	
	if ((interface == 0xFFU) || (interface >= USBH_MAX_NUM_INTERFACES)) /* No Valid Interface */
	{
		USBH_DbgLog("Cannot Find the interface for %s class.", phost->pActiveClass->Name);
		return USBH_FAIL;
	}

  status = USBH_SelectInterface(phost, interface);

  if (status != USBH_OK)
  {
    return USBH_FAIL;
  }

  phost->pActiveClass->pData = (HID_HandleTypeDef *)USBH_malloc(sizeof(HID_HandleTypeDef));
  HID_Handle = (HID_HandleTypeDef *) phost->pActiveClass->pData;

  if (HID_Handle == NULL)
  {
    USBH_DbgLog("Cannot allocate memory for HID Handle");
    return USBH_FAIL;
  }

  /* Initialize hid handler */
  (void)USBH_memset(HID_Handle, 0, sizeof(HID_HandleTypeDef));

  HID_Handle->state = USBH_HID_ERROR;

  //����HID�豸�� PID��VID���в�ͬ���豸����ʶ��
  if( phost->device.DevDesc.idProduct == Wired_PS2_PID && phost->device.DevDesc.idVendor==Wired_PS2_VID )
  {	  //����PS2�ֱ���PID/VID
	  USBH_UsrLog("Wired PS2 device found!");
	  ps2_type = Wired_PS2;
	  HID_Handle->Init = USBH_HID_PS2Init;
  }
  
  else if( phost->device.DevDesc.idProduct == Wireless_PC_PS2_PID && phost->device.DevDesc.idVendor==Wireless_PC_PS2_VID )
  {	  //����PS2�ֱ� PCģʽ PID/VID
	  USBH_UsrLog("Wireless PC PS2 device found!");
	  ps2_type = Wiredless_PC_PS2;
	  HID_Handle->Init = USBH_HID_PS2Init;
  }
  
  else if( phost->device.DevDesc.idProduct == Wireless_Android_PS2_PID && phost->device.DevDesc.idVendor==Wireless_Android_PS2_VID )
  {	  //����PS2�ֱ� Androidģʽ ��PID/VID
	  USBH_UsrLog("Wireless Android PS2 device found!");
	  ps2_type = Wiredless_Android_PS2;
	  HID_Handle->Init = USBH_HID_PS2Init;
  }
  
  else
  {
	ps2_type = UnKnown_Dev;//δ֪���豸����
    USBH_UsrLog("Protocol not supported.");
    return USBH_FAIL;
  }

  HID_Handle->state     = USBH_HID_INIT;
  HID_Handle->ctl_state = USBH_HID_REQ_INIT;
  HID_Handle->ep_addr   = phost->device.CfgDesc.Itf_Desc[interface].Ep_Desc[0].bEndpointAddress;
  HID_Handle->length    = phost->device.CfgDesc.Itf_Desc[interface].Ep_Desc[0].wMaxPacketSize;
  HID_Handle->poll      = phost->device.CfgDesc.Itf_Desc[interface].Ep_Desc[0].bInterval;
  
  if (HID_Handle->poll < HID_MIN_POLL)
  {
    HID_Handle->poll = HID_MIN_POLL;
  }

  /* Check of available number of endpoints */
  /* Find the number of EPs in the Interface Descriptor */
  /* Choose the lower number in order not to overrun the buffer allocated */
  max_ep = ((phost->device.CfgDesc.Itf_Desc[interface].bNumEndpoints <= USBH_MAX_NUM_ENDPOINTS) ?
            phost->device.CfgDesc.Itf_Desc[interface].bNumEndpoints : USBH_MAX_NUM_ENDPOINTS);


  /* Decode endpoint IN and OUT address from interface descriptor */
  for (num = 0U; num < max_ep; num++)
  {
    if ((phost->device.CfgDesc.Itf_Desc[interface].Ep_Desc[num].bEndpointAddress & 0x80U) != 0U)
    {
      HID_Handle->InEp = (phost->device.CfgDesc.Itf_Desc[interface].Ep_Desc[num].bEndpointAddress);
      HID_Handle->InPipe = USBH_AllocPipe(phost, HID_Handle->InEp);
      ep_mps = phost->device.CfgDesc.Itf_Desc[interface].Ep_Desc[num].wMaxPacketSize;

      /* Open pipe for IN endpoint */
      (void)USBH_OpenPipe(phost, HID_Handle->InPipe, HID_Handle->InEp, phost->device.address,
                          phost->device.speed, USB_EP_TYPE_INTR, ep_mps);

      (void)USBH_LL_SetToggle(phost, HID_Handle->InPipe, 0U);
    }
    else
    {
      HID_Handle->OutEp = (phost->device.CfgDesc.Itf_Desc[interface].Ep_Desc[num].bEndpointAddress);
      HID_Handle->OutPipe = USBH_AllocPipe(phost, HID_Handle->OutEp);
      ep_mps = phost->device.CfgDesc.Itf_Desc[interface].Ep_Desc[num].wMaxPacketSize;

      /* Open pipe for OUT endpoint */
      (void)USBH_OpenPipe(phost, HID_Handle->OutPipe, HID_Handle->OutEp, phost->device.address,
                          phost->device.speed, USB_EP_TYPE_INTR, ep_mps);

      (void)USBH_LL_SetToggle(phost, HID_Handle->OutPipe, 0U);
    }
  }
  return USBH_OK;
}

/**
  * @brief  USBH_HID_InterfaceDeInit
  *         The function DeInit the Pipes used for the HID class.
  * @param  phost: Host handle
  * @retval USBH Status
  */
static USBH_StatusTypeDef USBH_HID_InterfaceDeInit(USBH_HandleTypeDef *phost)
{
  HID_HandleTypeDef *HID_Handle = (HID_HandleTypeDef *) phost->pActiveClass->pData;

  if (HID_Handle->InPipe != 0x00U)
  {
    (void)USBH_ClosePipe(phost, HID_Handle->InPipe);
    (void)USBH_FreePipe(phost, HID_Handle->InPipe);
    HID_Handle->InPipe = 0U;     /* Reset the pipe as Free */
  }

  if (HID_Handle->OutPipe != 0x00U)
  {
    (void)USBH_ClosePipe(phost, HID_Handle->OutPipe);
    (void)USBH_FreePipe(phost, HID_Handle->OutPipe);
    HID_Handle->OutPipe = 0U;     /* Reset the pipe as Free */
  }

  if ((phost->pActiveClass->pData) != NULL)
  {
    USBH_free(phost->pActiveClass->pData);
    phost->pActiveClass->pData = 0U;
  }

  //�豸�γ�ʱ,�����з���ʼ��,ps2�ֱ�����Ҳ��Ҫһ��λ
  memcpy(&ps2_info,&ps2_defaultVal,sizeof(PS2INFO_t));
  
  //ps2�ֱ����͡�����ֵ��λ
  ps2_type = UnKnown_Dev;
  ps2_KeyVal = 0;
  
  PS2Control_Reset();
  
  return USBH_OK;
}

/**
  * @brief  USBH_HID_ClassRequest
  *         The function is responsible for handling Standard requests
  *         for HID class.
  * @param  phost: Host handle
  * @retval USBH Status
  */
static USBH_StatusTypeDef USBH_HID_ClassRequest(USBH_HandleTypeDef *phost)
{

  USBH_StatusTypeDef status         = USBH_BUSY;
  USBH_StatusTypeDef classReqStatus = USBH_BUSY;
  HID_HandleTypeDef *HID_Handle = (HID_HandleTypeDef *) phost->pActiveClass->pData;

  /* Switch HID state machine */
  switch (HID_Handle->ctl_state)
  {
    case USBH_HID_REQ_INIT:
    case USBH_HID_REQ_GET_HID_DESC:

      USBH_HID_ParseHIDDesc(&HID_Handle->HID_Desc, phost->device.CfgDesc_Raw);

      HID_Handle->ctl_state = USBH_HID_REQ_GET_REPORT_DESC;

      break;
    case USBH_HID_REQ_GET_REPORT_DESC:

      /* Get Report Desc */
      classReqStatus = USBH_HID_GetHIDReportDescriptor(phost, HID_Handle->HID_Desc.wItemLength);
      if (classReqStatus == USBH_OK)
      {
        /* The descriptor is available in phost->device.Data */
        HID_Handle->ctl_state = USBH_HID_REQ_SET_IDLE;
      }
      else if (classReqStatus == USBH_NOT_SUPPORTED)
      {
        USBH_ErrLog("Control error: HID: Device Get Report Descriptor request failed");
        status = USBH_FAIL;
      }
      else
      {
        /* .. */
      }

      break;

    case USBH_HID_REQ_SET_IDLE:

      classReqStatus = USBH_HID_SetIdle(phost, 0U, 0U);

      /* set Idle */
      if (classReqStatus == USBH_OK)
      {
        HID_Handle->ctl_state = USBH_HID_REQ_SET_PROTOCOL;
      }
      else
      {
        if (classReqStatus == USBH_NOT_SUPPORTED)
        {
          HID_Handle->ctl_state = USBH_HID_REQ_SET_PROTOCOL;
        }
      }
      break;

    case USBH_HID_REQ_SET_PROTOCOL:
      /* set protocol */
      classReqStatus = USBH_HID_SetProtocol(phost, 0U);
      if (classReqStatus == USBH_OK)
      {
        HID_Handle->ctl_state = USBH_HID_REQ_IDLE;

        /* all requests performed */
        phost->pUser(phost, HOST_USER_CLASS_ACTIVE);
        status = USBH_OK;
      }
      else if (classReqStatus == USBH_NOT_SUPPORTED)
      {
        USBH_ErrLog("Control error: HID: Device Set protocol request failed");
        status = USBH_FAIL;
      }
      else
      {
        /* .. */
      }
      break;

    case USBH_HID_REQ_IDLE:
    default:
      break;
  }

  return status;
}

/**
  * @brief  USBH_HID_Process
  *         The function is for managing state machine for HID data transfers
  * @param  phost: Host handle
  * @retval USBH Status
  */
static USBH_StatusTypeDef USBH_HID_Process(USBH_HandleTypeDef *phost)
{
  USBH_StatusTypeDef status = USBH_OK;
  HID_HandleTypeDef *HID_Handle = (HID_HandleTypeDef *) phost->pActiveClass->pData;
  uint32_t XferSize;

  switch (HID_Handle->state)
  {
    case USBH_HID_INIT:
      status = HID_Handle->Init(phost);

      if (status == USBH_OK)
      {
        HID_Handle->state = USBH_HID_IDLE;
      }
      else
      {
        USBH_ErrLog("HID Class Init failed");
        HID_Handle->state = USBH_HID_ERROR;
        status = USBH_FAIL;
      }

#if (USBH_USE_OS == 1U)
      phost->os_msg = (uint32_t)USBH_URB_EVENT;
#if (osCMSIS < 0x20000U)
      (void)osMessagePut(phost->os_event, phost->os_msg, 0U);
#else
      (void)osMessageQueuePut(phost->os_event, &phost->os_msg, 0U, 0U);
#endif
#endif
      break;

    case USBH_HID_IDLE:
		
	//����GetReport��������HID�豸��������.�ڴ�֮ǰ HID_Handle->pData ������ɳ�ʼ��,��һ��ͨ���� HID_Handle->Init �������,�����޷�����ɹ�
	
      status = USBH_HID_GetReport(phost, 0x01U, 0U, HID_Handle->pData, (uint8_t)HID_Handle->length);

      if (status == USBH_OK)
      {
        HID_Handle->state = USBH_HID_SYNC;
      }
      else if (status == USBH_BUSY)
      {
        HID_Handle->state = USBH_HID_IDLE;
        status = USBH_OK;
      }
      else if (status == USBH_NOT_SUPPORTED)
      {
        HID_Handle->state = USBH_HID_SYNC;
        status = USBH_OK;
      }
      else
      {
        HID_Handle->state = USBH_HID_ERROR;
        status = USBH_FAIL;
      }

#if (USBH_USE_OS == 1U)
      phost->os_msg = (uint32_t)USBH_URB_EVENT;
#if (osCMSIS < 0x20000U)
      (void)osMessagePut(phost->os_event, phost->os_msg, 0U);
#else
      (void)osMessageQueuePut(phost->os_event, &phost->os_msg, 0U, 0U);
#endif
#endif
      break;

    case USBH_HID_SYNC:
      /* Sync with start of Even Frame */
      if ((phost->Timer & 1U) != 0U)
      {
        HID_Handle->state = USBH_HID_GET_DATA;
      }

#if (USBH_USE_OS == 1U)
      phost->os_msg = (uint32_t)USBH_URB_EVENT;
#if (osCMSIS < 0x20000U)
      (void)osMessagePut(phost->os_event, phost->os_msg, 0U);
#else
      (void)osMessageQueuePut(phost->os_event, &phost->os_msg, 0U, 0U);
#endif
#endif
      break;

    case USBH_HID_GET_DATA:
		
	//����HID�豸������,������ HID_Handle->pData
      (void)USBH_InterruptReceiveData(phost, HID_Handle->pData,
                                      (uint8_t)HID_Handle->length,
                                      HID_Handle->InPipe);

      HID_Handle->state = USBH_HID_POLL;
      HID_Handle->timer = phost->Timer;
      HID_Handle->DataReady = 0U;
      break;

    case USBH_HID_POLL:
      if (USBH_LL_GetURBState(phost, HID_Handle->InPipe) == USBH_URB_DONE)
      {
        XferSize = USBH_LL_GetLastXferSize(phost, HID_Handle->InPipe);

        if ((HID_Handle->DataReady == 0U) && (XferSize != 0U) && (HID_Handle->fifo.buf != NULL))
        {
		  //��������HID_Handle->pData��HID�豸����д�뵽fifo�У�����ͨ��fifo����ȡhid�豸������
          (void)USBH_HID_FifoWrite(&HID_Handle->fifo, HID_Handle->pData, HID_Handle->length); 
          HID_Handle->DataReady = 1U;
          USBH_HID_EventCallback(phost);

#if (USBH_USE_OS == 1U)
          phost->os_msg = (uint32_t)USBH_URB_EVENT;
#if (osCMSIS < 0x20000U)
          (void)osMessagePut(phost->os_event, phost->os_msg, 0U);
#else
          (void)osMessageQueuePut(phost->os_event, &phost->os_msg, 0U, 0U);
#endif
#endif
        }
      }
      else
      {
        /* IN Endpoint Stalled */
        if (USBH_LL_GetURBState(phost, HID_Handle->InPipe) == USBH_URB_STALL)
        {
          /* Issue Clear Feature on interrupt IN endpoint */
          if (USBH_ClrFeature(phost, HID_Handle->ep_addr) == USBH_OK)
          {
            /* Change state to issue next IN token */
            HID_Handle->state = USBH_HID_GET_DATA;
          }
        }
      }
      break;

    default:
      break;
  }

  return status;
}

/**
  * @brief  USBH_HID_SOFProcess
  *         The function is for managing the SOF Process
  * @param  phost: Host handle
  * @retval USBH Status
  */
static USBH_StatusTypeDef USBH_HID_SOFProcess(USBH_HandleTypeDef *phost)
{
  HID_HandleTypeDef *HID_Handle = (HID_HandleTypeDef *) phost->pActiveClass->pData;

  if (HID_Handle->state == USBH_HID_POLL)
  {
    if ((phost->Timer - HID_Handle->timer) >= HID_Handle->poll)
    {
      HID_Handle->state = USBH_HID_GET_DATA;

#if (USBH_USE_OS == 1U)
      phost->os_msg = (uint32_t)USBH_URB_EVENT;
#if (osCMSIS < 0x20000U)
      (void)osMessagePut(phost->os_event, phost->os_msg, 0U);
#else
      (void)osMessageQueuePut(phost->os_event, &phost->os_msg, 0U, 0U);
#endif
#endif
    }
  }
  return USBH_OK;
}

/**
  * @brief  USBH_ParseHIDDesc
  *         This function Parse the HID descriptor
  * @param  desc: HID Descriptor
  * @param  buf: Buffer where the source descriptor is available
  * @retval None
  */
static void USBH_HID_ParseHIDDesc(HID_DescTypeDef *desc, uint8_t *buf)
{
  USBH_DescHeader_t *pdesc = (USBH_DescHeader_t *)buf;
  uint16_t CfgDescLen;
  uint16_t ptr;

  CfgDescLen = LE16(buf + 2U);

  if (CfgDescLen > USB_CONFIGURATION_DESC_SIZE)
  {
    ptr = USB_LEN_CFG_DESC;

    while (ptr < CfgDescLen)
    {
      pdesc = USBH_GetNextDesc((uint8_t *)pdesc, &ptr);

      if (pdesc->bDescriptorType == USB_DESC_TYPE_HID)
      {
        desc->bLength = *(uint8_t *)((uint8_t *)pdesc + 0U);
        desc->bDescriptorType = *(uint8_t *)((uint8_t *)pdesc + 1U);
        desc->bcdHID = LE16((uint8_t *)pdesc + 2U);
        desc->bCountryCode = *(uint8_t *)((uint8_t *)pdesc + 4U);
        desc->bNumDescriptors = *(uint8_t *)((uint8_t *)pdesc + 5U);
        desc->bReportDescriptorType = *(uint8_t *)((uint8_t *)pdesc + 6U);
        desc->wItemLength = LE16((uint8_t *)pdesc + 7U);
        break;
      }
    }
  }
}

///////////////////////// PS2 ��ʼ��ʵ�֡�����ʵ�� ///////////////////////////////
//ps2�ֱ������뱨��
static uint8_t ps2_report_data[64] = { 0 }; //���ڴ��HID�豸���͹���������

//ps2��ʼ������
USBH_StatusTypeDef USBH_HID_PS2Init(USBH_HandleTypeDef *phost)
{
	HID_HandleTypeDef *HID_Handle = (HID_HandleTypeDef *) phost->pActiveClass->pData;
	
	//HID_Handle->length�ڳ�ʼ���豸ʱ��HID�豸ȷ��
	if (HID_Handle->length > sizeof(ps2_report_data))
	{
		HID_Handle->length = (uint16_t)sizeof(ps2_report_data);
	}
	
	//��ʼ��pData,���벽��.
	HID_Handle->pData = ps2_report_data;
	
	if ((HID_QUEUE_SIZE * sizeof(ps2_report_data)) > sizeof(phost->device.Data))
	{	//sizeof(phost->device.Data) ��С�� USBH_MAX_DATA_BUFFER ����
		return USBH_FAIL;
	}
	else
	{
		//��ʼ��fifo
		USBH_HID_FifoInit(&HID_Handle->fifo, phost->device.Data, (uint16_t)(HID_QUEUE_SIZE * sizeof(ps2_report_data)));
	}
	

	PS2Control_Set();
	
	return USBH_OK;
}

//3��ģʽ���ֱ����ݽ������
static void Wired_PS2_Decode(const uint8_t *data);
static void Wiredless_PC_PS2_Decode(const uint8_t *data);
static void Wiredless_Android_PS2_Decode(const uint8_t *data);

//ps2���ݽ���,��ڲ���ΪHID�豸.���л���Ϊ����.
USBH_StatusTypeDef USBH_HID_PS2_Decode(USBH_HandleTypeDef *phost)
{
	HID_HandleTypeDef *HID_Handle = (HID_HandleTypeDef *) phost->pActiveClass->pData;
	
	//����Ƿ�ɹ�ʶ���ֱ�����
	if( ps2_type == UnKnown_Dev ) return USBH_FAIL;
	
	//���hid�豸�Ƿ�������
	if ((HID_Handle->length == 0U) || (HID_Handle->fifo.buf == NULL))
	{
		return USBH_FAIL;
	}
	
	//��fifo�ж�ȡhid���ݷ���ps2_report_data�������н���
	if (USBH_HID_FifoRead(&HID_Handle->fifo, (uint8_t* )ps2_report_data, HID_Handle->length) == HID_Handle->length)
	{
		//���ݲ�ͬ��ps2�豸ִ�в�ͬ�Ľ��뺯��
		if(  Wired_PS2 == ps2_type )
		{
			Wired_PS2_Decode(ps2_report_data);
		}
		else if( Wiredless_PC_PS2 == ps2_type )
		{
			Wiredless_PC_PS2_Decode(ps2_report_data);
		}
		else if( Wiredless_Android_PS2 == ps2_type )
		{
			Wiredless_Android_PS2_Decode(ps2_report_data);
		}
		
		return USBH_OK;
	}
	return   USBH_FAIL;

}

////////////////// PS2������⺯�� ///////////////
//16��ps2����
#define PS2_KEY_NUM 16 



//�������ʱ��,��λms
#define PS2_LONGPRESS_TIEM 1000 //�������ʱ��
#define PS2_CLICK_TIME     400  //��˫�����ʱ��
#define PS2_KEYFILTER_TIME 50   //�����˲�ʱ��

//״̬����״ֵ̬
typedef enum{
    WaitToPress = 0,
    WaitToRelease ,
    KEYPress    ,
    KEYUp       ,
    LONG_CLICK  ,
}PS2KEY_CheckState;

//��ⰴ�����µĸ�������
typedef struct 
{
    uint8_t keystate;       //������״̬,0��ʾ�ɿ�,1��ʾ������
    uint32_t timebase;      //��������ʱ��
    uint32_t statetime;     //״̬ͳ��ʱ��
    PS2KEY_CheckState statemachine; //��ⰴ����״̬��
}PS2_CheckKey_t;

PS2_CheckKey_t ps2key[PS2_KEY_NUM] = { 0 };

PS2KEY_State_t ps2_checkkey(uint8_t bit)
{
    PS2_CheckKey_t* key = &ps2key[bit]; //ָ��Ҫ�����һ������
    
    //��ȡ��Ӧ�ļ�ֵ״̬
    key->keystate = (ps2_KeyVal>>bit)&0x01;

    switch (key->statemachine)
    {
        case WaitToPress:
            if( PS2KEY_PressDOWN == key->keystate )
            {
                key->timebase = xTaskGetTickCount();
                key->statemachine = KEYPress;
            } 
            break;
        case KEYPress:
            //ͳ�Ƶ�һ�ΰ��°����Ժ��ʱ��(�޷������ʱ��Ȼ����.����Ҫ����ж�)
            key->statetime = xTaskGetTickCount() - key->timebase;

            //��鰴���Ƿ����ɿ�
            if( PS2KEY_PressUP == key->keystate )
            {
                //���ΰ������µ�ʱ��̫��,����.��Ϊ�˲�����
                if( key->statetime < PS2_KEYFILTER_TIME ) key->statemachine = WaitToPress;
                else
                {
                   key->timebase = xTaskGetTickCount();//���¸���ʱ��,������һ��״̬�ļ��
                   key->statemachine = KEYUp;    //��������һ��ʱ��,�ֵ���,������һ�����״̬
                }
            }
            else if( key->statetime > PS2_LONGPRESS_TIEM ) 
            {   //����δ�ɿ�,�ұ���һ����ʱ��,��Ϊ����.
                key->statemachine = LONG_CLICK;
            }

            break;
        case KEYUp:
            //ͳ�Ƶ�һ�ΰ��°����Ժ��ʱ��(�޷������ʱ��Ȼ����.����Ҫ����ж�)
            key->statetime = xTaskGetTickCount() - key->timebase;

            if( PS2KEY_PressDOWN == key->keystate && key->statetime < PS2_CLICK_TIME && key->statetime > PS2_KEYFILTER_TIME )
            {
                key->statemachine = WaitToRelease;
                return PS2KEYSTATE_DOUBLECLICK;
            }
            else if( key->statetime >= PS2_CLICK_TIME )
            {
                key->statemachine = WaitToRelease;
                return PS2KEYSTATE_SINGLECLICK;
            }
            break;
        case LONG_CLICK:
            key->statemachine = WaitToRelease;
            return PS2KEYSTATE_LONGCLICK;
        case WaitToRelease:
            //����������,���û��ɿ�������,�ٻָ�״̬����״̬
            if( PS2KEY_PressUP == key->keystate ) key->statemachine = WaitToPress;
            break;
        default:
            break;
    }

    return PS2KEYSTATE_NONE;
}

//ֱ�ӷ���������״ֵ̬
uint8_t ps2_checkkeystate(uint8_t bit)
{
    return (ps2_KeyVal>>bit)&0x01;
}

////////////////// PS2������⺯�� END ///////////////

///////////////////////////////////////////////// ���뺯��ϸ�� ////////////////////////////////////////////////////////
//��־λ���ú���,���ڸ���ps2�ֱ�����
static void ps2_set_bit(uint16_t* state,uint8_t state_bit,uint8_t bit)
{
	if(state_bit==1) //ָ����λ(bit)����Ϊ1,����λ����
	{
		*state |= (1U<<bit);
	}
	else //ָ����λ(bit)����Ϊ0,����λ����
	{
		*state &= ~(1U<<bit);
	}
}

//����PS2�ֱ������ݽ���
static void Wired_PS2_Decode(const uint8_t *data)
{
	uint8_t tmp_bool = 0 ;
	
	ps2_info.LX = data[3];
	ps2_info.LY = data[4];
	ps2_info.RX = data[1];
	ps2_info.RY = data[2];
	
	tmp_bool = (data[6]>>4)&0x01;
	ps2_set_bit(&ps2_KeyVal,tmp_bool,0); //seltec key ѡ�񰴼�
	
	tmp_bool = (data[6]>>6)&0x01;
	ps2_set_bit(&ps2_KeyVal,tmp_bool,1); //��ҡ�˰���
	
	tmp_bool = (data[6]>>7)&0x01;
	ps2_set_bit(&ps2_KeyVal,tmp_bool,2); //��ҡ�˰���
	
	tmp_bool = (data[6]>>5)&0x01;
	ps2_set_bit(&ps2_KeyVal,tmp_bool,3); //start
	
	tmp_bool = data[5]&0x0F;//ȡ����4λ
	if(tmp_bool==0x0F)//û���κΰ�������
	{
		ps2_set_bit(&ps2_KeyVal,0,4); //��
		ps2_set_bit(&ps2_KeyVal,0,5); //��
		ps2_set_bit(&ps2_KeyVal,0,6); //��
		ps2_set_bit(&ps2_KeyVal,0,7); //��
	}
	else if( (tmp_bool&0x01)==0 )
	{	
		switch ((tmp_bool>>1)&0x03)
		{
			case 0x00://��
				ps2_set_bit(&ps2_KeyVal,1,4); //��
				break;
			case 0x01://��
				ps2_set_bit(&ps2_KeyVal,1,5); //��
				break;
			case 0x02://��
				ps2_set_bit(&ps2_KeyVal,1,6); //��
				break;
			case 0x03://��
				ps2_set_bit(&ps2_KeyVal,1,7); //��
				break;
			default:
				break;
		}
	}
	else if( (tmp_bool&0x01)==1 ) //��λΪ1,������������2���������µ����
	{
		switch ((tmp_bool>>1)&0x03)
		{
			case 0x00://����
				ps2_set_bit(&ps2_KeyVal,1,4);//��
				ps2_set_bit(&ps2_KeyVal,1,5); //��
				break;
			case 0x01://����
				ps2_set_bit(&ps2_KeyVal,1,6); //��
				ps2_set_bit(&ps2_KeyVal,1,5); //��
				break;
			case 0x02://����
				ps2_set_bit(&ps2_KeyVal,1,6); //��
				ps2_set_bit(&ps2_KeyVal,1,7); //��
				break;
			case 0x03://����
				ps2_set_bit(&ps2_KeyVal,1,4); //��
				ps2_set_bit(&ps2_KeyVal,1,7); //��
				break;
			default:
				break;
		}
	}
	
	tmp_bool = (data[6]>>2)&0x01;
	ps2_set_bit(&ps2_KeyVal,tmp_bool,8); //����2��
	
	tmp_bool = (data[6]>>3)&0x01;
	ps2_set_bit(&ps2_KeyVal,tmp_bool,9); //�Ұ��2��
	
	tmp_bool = (data[6]>>0)&0x01;
	ps2_set_bit(&ps2_KeyVal,tmp_bool,10); //����1��
	
	tmp_bool = (data[6]>>1)&0x01;
	ps2_set_bit(&ps2_KeyVal,tmp_bool,11); //�Ұ��1��
	
	tmp_bool = (data[5]>>4)&0x01;
	ps2_set_bit(&ps2_KeyVal,tmp_bool,12); //һ��,��ɫGREEN
	
	tmp_bool = (data[5]>>5)&0x01;
	ps2_set_bit(&ps2_KeyVal,tmp_bool,13); //����,��ɫRED

	tmp_bool = (data[5]>>6)&0x01;
	ps2_set_bit(&ps2_KeyVal,tmp_bool,14); //����,����BLUE
	
	tmp_bool = (data[5]>>7)&0x01;
	ps2_set_bit(&ps2_KeyVal,tmp_bool,15); //�ĺ�,��ɫPINK
}

//���߰�׿ģʽ�ֱ����ݽ���
static void Wiredless_Android_PS2_Decode(const uint8_t *data)
{
	uint8_t tmp_bool = 0 ;
	
	uint8_t rm_val = 0;
	if( data[6]==0&&data[7]==0 ) rm_val=128;
	else rm_val = data[6];
	ps2_info.LX = rm_val;
	
	if( data[8]==0&&data[9]==0  ) rm_val=128;
	else rm_val = data[8];
	ps2_info.LY = 255 - rm_val;
	
	if( data[10]==0&&data[11]==0  ) rm_val=128;
	else rm_val = data[10];
	ps2_info.RX = rm_val;
	
	if( data[12]==0&&data[13]==0  ) rm_val=128;
	else rm_val = data[12];
	ps2_info.RY = 255 - rm_val;
	
	//data[2]
	//Rm    Lm    select   start    ��      ��       ��        ��
	//0		0		0		0		0		0		0		0
	tmp_bool = (data[2]>>0)&0x01;
	ps2_set_bit(&ps2_KeyVal,tmp_bool,4); //��
	
	tmp_bool = (data[2]>>3)&0x01;
	ps2_set_bit(&ps2_KeyVal,tmp_bool,5); //��
	
	tmp_bool = (data[2]>>1)&0x01;
	ps2_set_bit(&ps2_KeyVal,tmp_bool,6); //��
	
	tmp_bool = (data[2]>>2)&0x01;
	ps2_set_bit(&ps2_KeyVal,tmp_bool,7); //��
	
	tmp_bool = (data[2]>>5)&0x01;
	ps2_set_bit(&ps2_KeyVal,tmp_bool,0); //seltec key ѡ�񰴼�	
	
	tmp_bool = (data[2]>>4)&0x01;
	ps2_set_bit(&ps2_KeyVal,tmp_bool,3); //start key ѡ�񰴼�
	
	tmp_bool = (data[2]>>6)&0x01;
	ps2_set_bit(&ps2_KeyVal,tmp_bool,1); //��ҡ�˰���	
	
	tmp_bool = (data[2]>>7)&0x01;
	ps2_set_bit(&ps2_KeyVal,tmp_bool,2); //��ҡ�˰���
	
	tmp_bool = (data[3]>>0)&0x01;
	ps2_set_bit(&ps2_KeyVal,tmp_bool,10); //����1��
	
	tmp_bool = (data[3]>>1)&0x01;
	ps2_set_bit(&ps2_KeyVal,tmp_bool,11); //�Ұ��1��
	
	if(data[4]==0xff) tmp_bool=1;
	else tmp_bool=0;
	ps2_set_bit(&ps2_KeyVal,tmp_bool,8); //����2��
	
	if(data[5]==0xff) tmp_bool=1;
	else tmp_bool=0;
	ps2_set_bit(&ps2_KeyVal,tmp_bool,9); //�Ұ��2��
	
	tmp_bool = (data[3]>>4)&0x01;//BLUE
	ps2_set_bit(&ps2_KeyVal,tmp_bool,14);
	
	tmp_bool = (data[3]>>5)&0x01;//RED
	ps2_set_bit(&ps2_KeyVal,tmp_bool,13);
	
	tmp_bool = (data[3]>>6)&0x01;//PINK
	ps2_set_bit(&ps2_KeyVal,tmp_bool,15);
	
	tmp_bool = (data[3]>>7)&0x01;//GREEN
	ps2_set_bit(&ps2_KeyVal,tmp_bool,12);
}

//����pcģʽ�ֱ����ݽ���
static void  Wiredless_PC_PS2_Decode(const uint8_t *data)
{
	uint8_t tmp_bool = 0;
	
	ps2_info.LX = data[3];
	ps2_info.LY = data[4];
	ps2_info.RX = data[5];
	ps2_info.RY = data[6];
	
	tmp_bool = (data[1]>>0)&0x01;//select
	ps2_set_bit(&ps2_KeyVal,tmp_bool,0); //seltec key ѡ�񰴼�	
	
	tmp_bool = (data[1]>>1)&0x01;//start
	ps2_set_bit(&ps2_KeyVal,tmp_bool,3); //start key ѡ�񰴼�
	
	tmp_bool = (data[1]>>2)&0x01;//Lm
	ps2_set_bit(&ps2_KeyVal,tmp_bool,1); //��ҡ�˰���	
	
	tmp_bool = (data[1]>>3)&0x01;//Rm
	ps2_set_bit(&ps2_KeyVal,tmp_bool,2); //��ҡ�˰���
	
	tmp_bool = (data[0]>>4)&0x01;//L1
	ps2_set_bit(&ps2_KeyVal,tmp_bool,10); //����1��
	
	tmp_bool = (data[0]>>5)&0x01;//R1
	ps2_set_bit(&ps2_KeyVal,tmp_bool,11); //�Ұ��1��
	
	tmp_bool = (data[0]>>6)&0x01;//L2
	ps2_set_bit(&ps2_KeyVal,tmp_bool,8); //����2��
	
	tmp_bool = (data[0]>>7)&0x01;//R2
	ps2_set_bit(&ps2_KeyVal,tmp_bool,9); //����2��
	
	tmp_bool = (data[0]>>0)&0x01;//GREEN
	ps2_set_bit(&ps2_KeyVal,tmp_bool,12);
	
	tmp_bool = (data[0]>>1)&0x01;//RED
	ps2_set_bit(&ps2_KeyVal,tmp_bool,13);
	
	tmp_bool = (data[0]>>2)&0x01;//BLUE
	ps2_set_bit(&ps2_KeyVal,tmp_bool,14);
	
	tmp_bool = (data[0]>>3)&0x01;//PINK
	ps2_set_bit(&ps2_KeyVal,tmp_bool,15);
	
	tmp_bool = data[2]&0x0F;//ȡ����4λ
	if(tmp_bool==0x0F)//û���κΰ�������
	{
		ps2_set_bit(&ps2_KeyVal,0,4); //��
		ps2_set_bit(&ps2_KeyVal,0,5); //��
		ps2_set_bit(&ps2_KeyVal,0,6); //��
		ps2_set_bit(&ps2_KeyVal,0,7); //��
	}
	else if( (tmp_bool&0x01)==0 )
	{	
		switch ((tmp_bool>>1)&0x03)
		{
			case 0x00://��
				ps2_set_bit(&ps2_KeyVal,1,4); //��
				break;
			case 0x01://��
				ps2_set_bit(&ps2_KeyVal,1,5); //��
				break;
			case 0x02://��
				ps2_set_bit(&ps2_KeyVal,1,6); //��
				break;
			case 0x03://��
				ps2_set_bit(&ps2_KeyVal,1,7); //��
				break;
			default:
				break;
		}
	}
	else if( (tmp_bool&0x01)==1 ) //��λΪ1,������������2���������µ����
	{
		switch ((tmp_bool>>1)&0x03)
		{
			case 0x00://����
				ps2_set_bit(&ps2_KeyVal,1,4);//��
				ps2_set_bit(&ps2_KeyVal,1,5); //��
				break;
			case 0x01://����
				ps2_set_bit(&ps2_KeyVal,1,6); //��
				ps2_set_bit(&ps2_KeyVal,1,5); //��
				break;
			case 0x02://����
				ps2_set_bit(&ps2_KeyVal,1,6); //��
				ps2_set_bit(&ps2_KeyVal,1,7); //��
				break;
			case 0x03://����
				ps2_set_bit(&ps2_KeyVal,1,4); //��
				ps2_set_bit(&ps2_KeyVal,1,7); //��
				break;
			default:
				break;
		}
	}	
}
///////////////////////////////////////////////// ���뺯��ϸ�� END ////////////////////////////////////////////////////////
